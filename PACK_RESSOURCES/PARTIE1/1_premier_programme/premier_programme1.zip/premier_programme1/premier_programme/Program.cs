﻿using System;

namespace premier_programme
{
    class Program
    {
        static void Main(string[] args) {

            Console.WriteLine("Bonjour je m'appelle Toto.");
            Console.WriteLine("Toto, c'est bien mon nom");


        }
    }
}
