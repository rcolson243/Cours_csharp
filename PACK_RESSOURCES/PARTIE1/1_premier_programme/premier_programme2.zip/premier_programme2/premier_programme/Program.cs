﻿using System;

namespace premier_programme
{
    class Program
    {
        static void Main(string[] args) {

            Console.OutputEncoding = System.Text.Encoding.UTF8;

            string nomDeLaPersonne = "Valérie";
            Console.WriteLine("Bonjour je m'appelle " + nomDeLaPersonne);
            Console.WriteLine(nomDeLaPersonne + ", c'est bien mon nom");


        }
    }
}
